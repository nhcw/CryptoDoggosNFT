const getShortAddress = (address: string | undefined | null) => {
  if (address && address.startsWith('0x')) {
    return address.substr(0, 4) + '...' + address.substr(address.length - 4);
  }
  return address;
};

export default getShortAddress;
